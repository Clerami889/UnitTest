package com.clerami.intermediate.ui.story

import org.junit.Assert.*

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.Observer
import androidx.paging.PagingData
import androidx.paging.PagingDataAdapter
import androidx.paging.PagingSource
import androidx.paging.PagingState
import androidx.paging.map
import androidx.recyclerview.widget.ListUpdateCallback
import com.clerami.intermediate.data.remote.response.ListStoryItem
import com.clerami.intermediate.data.remote.retrofit.ApiService
import com.clerami.intermediate.ui.story.StoryRepository
import com.clerami.intermediate.ui.story.StoryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapConcat
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.ArgumentMatchers.argThat
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

@OptIn(ExperimentalCoroutinesApi::class)
@ExperimentalCoroutinesApi
class StoryViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private lateinit var viewModel: StoryViewModel

    @Mock
    private lateinit var storyRepository: StoryRepository

    @Mock
    private lateinit var apiService: ApiService

    @Mock
    private lateinit var observerStories: Observer<PagingData<ListStoryItem>>

    @Mock
    private lateinit var observerIsLoading: Observer<Boolean>

    @Mock
    private lateinit var observerErrorMessage: Observer<String>

    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        viewModel = StoryViewModel(storyRepository, apiService)

        Dispatchers.setMain(testDispatcher)

        viewModel.stories.observeForever(observerStories)
        viewModel.isLoading.observeForever(observerIsLoading)
        viewModel.errorMessage.observeForever(observerErrorMessage)
    }

    @Test
    fun `test getStories success and ensure data is emitted`() = runTest {
        val token = "test_token"
        val mockStories = listOf(
            ListStoryItem(
                id = "1",
                name = "Test Story",
                description = "Test Description",
                photoUrl = "http://example.com/photo.jpg",
                createdAt = "2023-01-01",
                lat = 0.0,
                lon = 0.0
            )
        )

        // Create a PagingData using PagingSource
        val pagingSource = MockPagingSource(mockStories)
        val mockPagingData = PagingData.from(mockStories)

        // Mock repository
        Mockito.`when`(storyRepository.getStories("Bearer $token")).thenReturn(flowOf(mockPagingData))

        // Call ViewModel method
        viewModel.getStories(token)

        // Verify loading state
        Mockito.verify(observerIsLoading).onChanged(true)
        Mockito.verify(observerIsLoading).onChanged(false)

        // Verify stories are emitted
        Mockito.verify(observerStories).onChanged(mockPagingData)
    }

    @Test
    fun `test getStories returns no data`() = runTest {
        val token = "test_token"

        // Empty list for no data scenario
        val mockPagingData = PagingData.empty<ListStoryItem>()

        // Mock repository
        Mockito.`when`(storyRepository.getStories("Bearer $token")).thenReturn(flowOf(mockPagingData))

        // Call ViewModel method
        viewModel.getStories(token)

        // Verify loading state
        Mockito.verify(observerIsLoading).onChanged(true)
        Mockito.verify(observerIsLoading).onChanged(false)

        // Verify empty data is emitted
        Mockito.verify(observerStories).onChanged(mockPagingData)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    // Mock PagingSource for creating PagingData
    class MockPagingSource<T : Any>(private val data: List<T>) : PagingSource<Int, T>() {
        override suspend fun load(params: LoadParams<Int>): LoadResult<Int, T> {
            return LoadResult.Page(
                data = data,
                prevKey = null,
                nextKey = null
            )
        }

        override fun getRefreshKey(state: PagingState<Int, T>): Int? {
            return null
        }
    }
}

